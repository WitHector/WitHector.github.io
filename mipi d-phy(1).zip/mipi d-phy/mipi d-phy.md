<div align="center">

# MIPI D-PHY

</div>

## 1 MIPI D-PHY介绍
### 1.1 关于MIPI
- MIPI - Mobile Industry Processor Interface
- 两个通过MIPI通信的硬件结构如下图：

    ![mipi通信](/mipi%E9%80%9A%E4%BF%A1%E7%BB%93%E6%9E%84%E5%9B%BE.png) 

    - PHY LAYER为物理层 （如D-PHY）
    - low level protocol和lane management为中间层（如DSI和CSI）
    - application为应用层
### 1.2 关于D-PHY
- DSI - Display Serial Interface (主机与显示模块之间的高速串行接口)
- D-PHY为DSI提供一个物理层定义

  ![ppi&appi](/ppi%E5%92%8Cappi.png)

    - MIPI连接包含一个master设备和一个slave设备，主设备向clock lane提供高速时钟信号，是主要的时钟源；slave设备是主要的设备接受端。从主设备到从设备为正向传输，所有的情况下时钟信号都保持正向传输，只有双向data lane才能反向传输。
    - D-PHY包括 one clock Lane and one or more Data Lane
    - Clock Lane总是单(正)向的，Data Lane可以双向
    - lane types
      - 单向Clock Lane
      - 单向Data Lane
      - 双向Data Lane

  - 传输模式：
    - low power，主要用于控制(CTRL)
    - high speed，主要用于高速数据(DATA)传输
  
  - HS模式和LP模式区别
   ||HS模式|LP模式|
    |:---:|:---:|:---:|
    |传输模式|差分信号|单端信号|
    |传输速度|80M-1.5Gbps|<10Mbps|
    |功耗|大|小|
    
- 最小数据单元--- 1 byte  (LSB first)

## 2 Lane Module
- lane内部结构如下图：

  ![lane module arch](./lane%20module%20arch.png)

  - PHY由多个D-PHY组成 一个D-PHY实际上就是一个Lane Module
  - D-PHY主要输入输出：
    - LP-TX
    - LP-RX
    - HS-TX
    - HS-RX
    - LP-CD(low power contention detector)
  - 通过两根线Dp和Dn与另一侧lane连接通信
  - <mark>DSI实际配置中，DATA0的LP双向，HS单向，其他的DATA LANE的LP和HS均为单向</mark>

- Lane Module的主要类型配置
  - 单向 Clock Lane
    - Master: HS-TX LP-TX
    - Slave: HS-RX LP-RX
  - 单向 Data Lane
    - Master: HS-TX LP-TX
    - Slave: HS-RX LP-RX
  - 双向 Data Lane
    - Master/Slave: HS-TX  HS-RX LP-RX LP-TX LP-CD

## 3 lane states and line level(Dp and Dn)
- 同样的两根线Dp和Dn，HS模式使用的是差分信号，因此同一时刻根据两根线上的电平只能得出0/1两种结果；LP模式使用的是单端信号，因此可能存在00/01/10/11四种情况
- 关于lane state和line level的描述见下图 
  
  ![lane state and line level](/lane%20state%20and%20line%20level.png)

  - note 1: 在高速传输时，LP receiver在线上观察到的状态始终是LP-00
  - note 2：如果在escape mode中出现LP-11, lane module会返回一个停止状态(也就是control mode 下的 LP-11)

## 4 Data Lane 操作模式
- data lane有三种操作模式-- <mark>Control Mode、High-Speed(Data Burst) Mode、Escape Mode</mark>
- 在control mode下以stop state作为起始信号可以提出进入以下三种模式的请求：
  - **Escape Mode Requset: (LP-11→LP-10→LP-00→LP-01→LP-00)**
  - **High-Speed Request: (LP-11→LP-01→LP-00)**
  - **Turnaround Request: (LP-11→LP-10→LP-00→LP-10→LP-00)**

### 4.1 Escape Mode
- Escape Mode 是 Data Lane 在 LP 状态下的一种特殊操作模式
- Escape Mode下有以下三种可用的附加功能：
  - LPDT (Low-Power Data Transmission)
  - ULPS (Ultra Low-Power State)
  - Trigger
- 一旦进入Escape Mode，需要发送8 bit的entry command来指示所请求的动作
- escape mode下的传输格式如下图：

  ![escape mode fromat](./escape%20mode%20format.png)

- Escape Mode 下对Data Lane的操作的时钟不依赖于Clock Lane，而是由Dp和Dn异或产生的时钟信号
- Escape Mode 使用 Spaced-One-Hot Encoding
  - **每一个要传输的状态都要与一个Space State(LP-00)交错进行(上图中每个虚线周期内有体现)**
  - **在每一个Space State后面发送Mark-0/1（见第三章图）表示传输一个0-bit 或者 1-bit**
- **Data Lane退出Escape Mode的指令：LP-10→LP-11**
- 关于上图中的Entry Command见下图，可通过下图中的code进入不同的state或者trigger

  ![escape entry codes](./escape%20entry%20codes.png)

- 下面对几种state 和 trigger进行说明：
  - Remote Triggers（只有一个reset trigger）:If the Entry Command Pattern matches the Reset-Trigger Command a Trigger is flagged to the protocol at the receive side via the logical PPI. Any bit received after a Trigger Command but before the Lines go to Stop state shall be ignored. Therefore, dummy bytes can be concatenated in order to provide Clock information to the receive side.（不是很理解这个作用）
  - Low-Power Data Transmission(LPDT): 
    - 低速传输数据
    - 同样使用Spaced-One-Hot Encoding
    - 同样不依赖Clock Lane，使用自编码的时钟
    - 传输过程中可以保持Space State来暂停传输

  - Ultra Low-Power State类似于休眠模式
    - 处于ULPS时，Dp和Dn处于Space state(LP-00)
    - 退出ULPS：长度为T(wakeup)=1ms的Mark-1,然后一个Stop state

### 4.2 High-Speed Mode(Data Burst)
- 所有的Lane同步开始
- 不同的Lane可能在不同的时机结束
- Clock Lane应该处于High-Speed Mode，向Slave side 提供一个DDR时钟
- 开始传输序列如下图

  ![Start-of-Transmission Sequence](./Start-of-Transmission%20Sequence.png)

- 结束传输序列如下图

  ![End-of-Transmission Sequence](./End-of-Transmission%20Sequence.png)

- 传输示例见下图

  ![High-Speed Data Transmission in Bursts](./High-Speed%20Data%20Transmission%20in%20Bursts.png)

  - 图中蓝色线条表示单端信号（LP-Control）
  - 图中红色线条表示差分信号（HS-Data Burst）

### 4.3 Bi-directional Data Lane Turnaround
- 双向数据通道允许通过Turnaround Procedure使数据在与当前方向相反的方向传输
- 正向改为反向或者反向改为正向的步骤相同
- 只能更改数据传输方向，不能改变Master和Slave side
- Turnaround 应该完全在 LP-Control Mode下进行
- Tunraround 序列如下图所示：

  ![Turnaround Sequence1](./Turnaround%20Sequence1.png)
  ![Turnaround Sequence2](./Turnaround%20Sequence2.png)

- Turnaround Procedure 示例时序图如下：

  ![Turnaround Procedure](./Turnaround%20Procedure.png)

## 5 Clock Lane
- 支持High-Speed和ULPS Clock Lane
### 5.1 High-Speed Clock Transmission
- 时钟信号相位应该与正向数据通道上的bit切换序列相位正交
- Data Burst 传输的第一个 bit 应该在时钟信号的上升沿
- High-Speed Clock Transmission初始化和结束为LP Mode的时序如下图
  
  ![Procedure to Initiate High-Speed Clock Transmission](./Procedure%20to%20Initiate%20High-Speed%20Clock%20Transmission.png)

- 当最后一个Data Lane完成HS Data Transmission后，以HS-0结束，并且进入LP Mode，高速时钟信号应继续运行T(CLK-POST)时间，下图给出了Clock Lane由High-Speed Clock Transmission切换至LP Mode和由LP Mode 切换至High-Speed Clock Transmission的过程

  ![Switching the Clock Lane between Clock Transmission and Low-Power Mode](./Switching%20the%20Clock%20Lane%20between%20Clock%20Transmission%20and%20Low-Power%20Mode.png)

### 5.2 Clock Lane Ultra-Low Power State
- 进入Ultra-Low Power State
  1. Stop state (LP-11)
  2. TX-ULPS-Rqst State (LP-10)
  3. TX-ULPS State (LP-00)
  4. 进入 Ultra-Low Power State后，两条线保持TX-ULPS State (LP-00)
- 退出Ultra-Low Power State ： Mark-1 TX-ULPS-Exit State

## 6 System Power States
- 三种功耗等级
  1. High-Speed Transmission mode
  2. Low-Power mode
  3. Ultra-Low Power State

## 7 Lane Module初始化
- Master Lane Module的初始化由系统输入信号完成
- Slave Lane Module的初始化由Master发出一个时长超过T(INIT)的STOP信号完成

  ![Initialization States](./Initialization%20States.png)

## 8 状态变换总结
- Data Lane

  ![Data Lane Module State Diagram](./Data%20Lane%20Module%20State%20Diagram.png)

- Clock Lane
  
  ![Clock Lane Module State Diagram](./Clock%20Lane%20Module%20State%20Diagram.png)

## 附录-时间参数

![Global Operation Timing Parameters1](./Global%20Operation%20Timing%20Parameters1.png)
![Global Operation Timing Parameters2](./Global%20Operation%20Timing%20Parameters2.png)
![Global Operation Timing Parameters3](./Global%20Operation%20Timing%20Parameters3.png)


<div align="center">

# DSI Introduction
*参考文档：《MIPI_DSI_Specification_V1.02.00》*
</div>

## 1 MIPI DSI 简介
- Display Serial Interface，用于显示模块的一个串行接口，基于MIPI协议而产生，兼容DPI(Display Pixel Interface)、DBI(Display Bus Interface)、DCS(Display Command Set
- 接口定义示意图如下
  
    ![接口定义示意图](./%E6%8E%A5%E5%8F%A3%E5%AE%9A%E4%B9%89%E7%A4%BA%E6%84%8F%E5%9B%BE.png)

- MIPI-DSI具备高速模式和低速模式两种工作模式，全部数据通道（1~4组数据通道）都可以用于单向的高速传输，但只有第一个数据通道(DATA Lane 0)才可用于低速双向传输*关于高速模式和低速模式参考D-PHY的那篇blog*

## 2 DSI分层
- DSI分层结构图（与D-PHY中的第一张图相同，D-PHY完成其物理层的工作）

    ![DSI分层图](./dsi%E5%88%86%E5%B1%82%E5%9B%BE.png)

### 2.1 PHY-Layer:物理层，上一篇blog已作详细介绍
### 2.2 Lane Management
- 通道管理层，对于Master来说，负责将所有的数据按照一定顺序分配给所有的数据Lane；对于Slave来说，负责从所有的Data Lane接收数据后将数据重组为原始数据
- 通道分配关系如下图：

    ![通道分配关系](./%E9%80%9A%E9%81%93%E5%88%86%E9%85%8D%E5%85%B3%E7%B3%BB.png)

### 2.3 Low Level Protocol
- 协议层，负责对数据进行封包（Master）或者错误校验（Slave）
- 信息传输采用两种数据格式--长数据包(long packet)和短数据包(short packet),发送数据时根据数据类型和内容对数据进行封装，完成ECC码和CRC码的添加；接收数据的时候根据ECC码和CRC校验码对数据包进行校验。
- 两种数据包的结构如下图所示：

    ![数据包格式](./%E6%95%B0%E6%8D%AE%E5%8C%85%E6%A0%BC%E5%BC%8F.png)

- 短数据包(short packet)
  - 只有数据包头
  - 固定长度四个字节
    - byte3：Data Identifier (DI)，0-5bit描述数据类型(详细见附录)，6-7bit描述通道号
    - byte1-2：Packet Data，命令或者数据（有效荷载），Data0为寄存器地址，Data1为值，如果不需要值将Data1置为0
    - byte0：ECC码
- 长数据包(long packet)
  - 不固定长度，长度范围为 4+(0~65535)+2 = 6~65541bytes
  - 包头由DI、两字节的WordCount（数据长度，不含Checksum）和一个字节的ECC码组成
  - 校验和为2bytes
### 2.4 Application
- 应用层，在此层对命令和数据进行初步编码转化为MIPI-DSI所规定的格式并发送（Master）；图将接收的数据还原为应用模块所支持的数据格式及时序要求（Slave）

## 3 Command Mode and Video Mode
- command mode的屏幕一般就是一些单片机或者低端产品上会用的液晶屏幕，它们在发送图像和命令时需要先制定写入地址。而我们日常所使用到的mipi液晶屏基本都是video mode的屏幕，刷新时是整个屏幕的进行刷新，不需要我们去先指定地址。
- 同步刷新机制：
  - command mode：通过TE pin来同步
  - video mode：通过将v-sync及h-sync信号包含在数据包里发送给panel来做同步
- Command Mode：对于本身有framebuffer的外设，使用command Mode向其指定地址写入数据，使其更新显示屏幕，主要用与静态显示的屏幕，更新频率较低，需要双向接口
- video mode：不间断的向外设发送像素流数据，实时更新，多用于动态图像显示，更新频率高，数据只能在HS Mode下传输（有些video mode架构中存在简单的时钟控制器和部分framebuffer，在低功耗时允许保持部分屏幕或者以低分辨率显示屏幕，从而达到允许关闭接口降低功耗的目的），为了降低系统复杂性和成本，至工作在video mode下的系统可能仅仅使用一个单向数据通道。

## 4 时钟管理
- DSI clock是从host到外设的时钟信号：
  - DSI Bit　Clock:作源同步位时钟，用于捕获接收端接口中的串行数据位
  - Byte Clock：在协议层和应用层接口之间作字节时钟，在协议层和应用层之间的操作都与此字节时钟保持同步
  - Application Clock：DSI位时钟的分频版本可用于外围设备的其他时钟功能。这些“应用程序时钟”可能需要在没有串行数据传输时运行，或者它们可能需要持续运行（连续时钟）以支持外围设备的有源电路。（非标）
- 时钟计算公式：<mark>dsi clk = Bitclk / 2  = H-total x V-total x fps x 位深 / lane number / 2</mark>
  - H-total：行所有像素点 行分辨率还要加上HSYNC和HBP、HFP
  - V-total: 列所有限速点 列分辨率还要加上VSYNC和VBP、VFP
  - /2的原因是MIPI采用的双边沿触发，一个时钟脉冲会触发两次
  - fps：帧数
  - 位深：每个像素的数据位，rgb888-24 rgb565-16

## 5 数据传输方法
- 最简单的传输状况，一个Transmiss包含一个packet，但是multiple packets时，由于每次HS mode传输间会插入LPS(Low-Power State)，这样效率会很低。所有有如下Separate transmission和Single Transmission两种传输方式，目的就是在一次Transmission中能狗传输多个packets

    ![transmission packets](./transmission%20packets.png)

- DSI 协议层还提供了一个专用的short packet用于表示传输结束（EoTp-end of transmission packet）,这个packet默认是disable状态，enable方法没有在Specification文件中说明，用的比较少。

    ![EoTp transmission packets](./EoTp%20transmisson%20packet.png)

## 6 video mode 接口时序
- video mode下的三种操作模式如下：
- 下面图中顶部有圆弧的代表数据包，长方形的代表时序的状态
- video中用到的数据包有以下几种(具体packet见附录)
  |packet|description|
  |:---:|:---:|
  |VSS|DSI Sync Event Packet: V Sync Start|
  |VSE|DSI Sync Event Packet: V Sync End|
  |BLLP|DSI Packet: Arbitrary sequence of non-restricted DSI packets or Low Power Mode incluing optional BTA|
  |HSS|DSI Sync Event Packet: H Sync Start|
  |HAS|DSI Blanking Packet: Horizontal Sync Active or Low Power Mode, No Data|
  |HSE|DSI Sync Event Packet: H Sync End|
  |HFP|DSI Blanking Packet: Horizontal Front Porch or Low Power Mode|
  |HBP|DSI Blanking Packet: Horizontal Back Porch or Low Power Mode|
  |RGB|DSI Packet: Arbitrary sequence of pixel stream and Null Packets|
  |LPM|Low Power Mode incuding optional BTA|
### 6.1 Non-Burst Mode with Sync Pulses
- 使用此格式，目标是通过DSI串行链路准确传达DPI类型的时序，包括匹配DPI像素传输速率和同步脉冲的宽度等，因此，使用传输同步脉冲的开始和结束的来定义同步周期。

    ![non burst with sync](./nonburst%20with%20sync%20.png)

    - HSA (Horizontal Sync Active)
    - HBP (Horizontal Back Porch)
    - HFP (Horizontal Front Porch)
    - 以上三个阶段一般由空数据包填充，且处于以上三个阶段时，Lane保持LP-11状态
### 6.2 Non-Burst Mode with Sync Events
- 是 Non-Burst Mode with Sync Pulses的简化版，只传输同步脉冲的开始信号，外围设备可以根据需要从接收到的每个同步事件包中重新生成同步脉冲。

    ![non burst with sync events](./non%20burst%20with%20sync%20events.png)

### 6.3 Burst mode(用的最多)
- 在horizontal 的时序是一样的情况下DSI会把连接的速度提升到Panel支持的最大速度。在这种模式下发送RGB数据包的时间被压缩，以留出更多的时间用来传送其他的数据。
  ![burst mode](./burst%20mode.png)

### 6.4 参数

  ![parameters](./Parameters.png)
  ![parameters2](./Parameters2.png)

### 6.5 总结
- 上述三种模式的时序框架都是相同的，VSA Lines、 VBP Lines 和 VFP Lines是帧同步时序所必须的，在Active Video Area里面对每一行进行刷新，每一行的数据包由行同步所必须的数据包加上RGB数据包组成

## 附录 Packet Data Types
- 文档 MIPI_DSI_Specification_V1.02.00 第八章有关于各个data type的详细描述
    ![packet data type 1](./packet%20data%20type1.png)
    ![packet data type 2](./packet%20data%20type%202.png)

